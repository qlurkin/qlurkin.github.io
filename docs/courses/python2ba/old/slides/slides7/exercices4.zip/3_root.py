# Écrire une fonction nommée root qui renvoie une solution à l'équation :
# cos(x) - x = 0

def root():
    #Votre code ici

if __name__ == "__main__":
    print(root())