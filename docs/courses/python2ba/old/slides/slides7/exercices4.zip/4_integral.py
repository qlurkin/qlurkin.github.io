# Écrire une fonction nommée integral qui renvoie l'intégrale définie de 
# f(x) = exp(2x)cos(x) entre 0 et 3π/2

def integral():
    # Votre code ici

if __name__ == "__main__":
    print(integral())