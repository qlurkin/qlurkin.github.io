# 3 points
# Écrivez la fonction equadiff() qui résout l'équation différentielle
# représentée dans le fichier equadiff.jpeg.
# L'équation différentielle devra être résolue entre t=0 et t=10 avec
# la condition initiale y(0) = 4.
# la fonction equadiff() devra renvoyer les points de y(t) sous forme
# d'une liste de tuples. Chaque tuple représentant un point (t, y(t)).


def equadiff():
    pass


if __name__ == "__main__":
    print(equadiff())  # affiche [(0.0, 4.0), ...
