# 4 points
# Créez une classe nommée Address dont le constructeur prend un nom de rue, un
# numéro de maison, un code postal et une vile en paramètres. Les objets
# s'afficheront dans le format d'adresse suivant lors d'un print():
#
# adr = Adresse("Promenade de l'Alma", 50, 1200, "Bruxelles")
# print(adr)
#
# affiche:
#
# Promenade de l'Alma, 50
# 1200 Bruxelles


class Address:
    pass


if __name__ == "__main__":
    adr = Address("Promenade de l'Alma", 50, 1200, "Bruxelles")
    print(adr)
    # affiche:
    #
    # Promenade de l'Alma, 50
    # 1200 Bruxelles
