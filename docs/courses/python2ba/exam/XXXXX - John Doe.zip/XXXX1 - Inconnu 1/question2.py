# 4 points
# Écrire une fonction nommée order_total() qui prend une database et un
# identifiant de commande (order_id) et qui renverra le prix total de la commande.
# la database aura la structure suivante :
#
# database = {
#     "clients": {
#         1: {"firstname": "Quentin", "lastname": "Lurkin"},
#         2: {"firstname": "André", "lastname": "Lorge"},
#         4: {"firstname": "Clémence", "lastname": "Flémal"},
#     },
#     "articles": {
#         12: {"name": "PS5", "price": 399},
#         35: {"name": "Jupiler", "price": 1.99},
#         37: {"name": "Pomme", "price": 0.89},
#         39: {"name": "Spa 50cl", "price": 1.89},
#     },
#     "orders": {
#         42: {
#             "client": 2,
#             "articles": [{"id": 12, "quantity": 1}, {"id": 37, "quantity": 5}],
#         },
#         69: {
#             "client": 1,
#             "articles": [
#                 {"id": 12, "quantity": 2},
#                 {"id": 35, "quantity": 10},
#                 {"id": 39, "quantity": 10},
#             ],
#         },
#     },
# }
#
# La database est donc un dictionnaire qui contient trois types de données
# (les clients, les articles et les commandes (orders)). Chacun de ces types de données
# est organisé sous forme d'un dictionnaire associant un identifiant entier (id)
# et un dictionnaire. Ce dernier contient les attributs propres à ce type de
# données. De plus, les commandes contiennent une liste d'articles et les
# quantités correspondantes.
#
# Exemple:
#
# La commande 42 a été faite par le client 2 (André Lorge). Elle contient
# deux articles: l'article 12 (PS5) avec une quantité de 1 et l'article 37
# (Pomme) avec une quantité de 5. Le total de cette commande est donc de
# 399 * 1 + 0.89 * 5 = 403.45


def order_total(database, order_id):
    pass


if __name__ == "__main__":
    database = {
        "clients": {
            1: {"firstname": "Quentin", "lastname": "Lurkin"},
            2: {"firstname": "André", "lastname": "Lorge"},
            4: {"firstname": "Clémence", "lastname": "Flémal"},
        },
        "articles": {
            12: {"name": "PS5", "price": 399},
            35: {"name": "Jupiler", "price": 1.99},
            37: {"name": "Pomme", "price": 0.89},
            39: {"name": "Spa 50cl", "price": 1.89},
        },
        "orders": {
            42: {
                "client": 2,
                "articles": [{"id": 12, "quantity": 1}, {"id": 37, "quantity": 5}],
            },
            69: {
                "client": 1,
                "articles": [
                    {"id": 12, "quantity": 2},
                    {"id": 35, "quantity": 10},
                    {"id": 39, "quantity": 10},
                ],
            },
        },
    }

    print(order_total(database, 42))  # affiche 403.45
