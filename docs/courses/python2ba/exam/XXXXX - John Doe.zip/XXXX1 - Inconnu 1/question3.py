# 4 points
# Écrire une fonction nommée unique() que prend le chemin d'un fichier JSON en
# paramètre. Le fichier JSON contiendra une liste de chaines de caractères. La
# fonction doit modifier la liste pour que chaque chaine de caractères
# n'apparaissent qu'une fois et sauver le résultat dans un nouveau fichier dont
# le nom est le même que l'ancien avec ".unique.json" à la place de ".json".
#
# Exemple de fichier d'entrée:
#
# ["un", "deux", "trois", "deux", "quatre"]
#
# Résultat attendu:
#
# ["un", "deux", "trois", "quatre"]
#
# L'ordre des éléments doit être préservé. On ne garde que la première
# occurrence de chaque chaine de caractères.


def unique(path):
    pass


if __name__ == "__main__":
    unique("data.json")

    with open("data.unique.json") as file:
        print(file.read())
