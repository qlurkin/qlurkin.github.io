# 4 points
# Écrire une fonction nommée letter_sets() qui prend une phrase en paramètre
# et qui renvoie la liste des ensembles de lettres de chaque mot. On suppose
# que les mots sont séparés par un seul espace dans la phrase d'origine.
#
# Exemple:
#
#   letter_sets("Je suis un as de la programmation")
#
# renvoie:
#
#   [{'J', 'e'}, {'i', 'u', 's'}, {'n', 'u'}, {'a', 's'}, {'e', 'd'}, {'l', 'a'}, {'r', 't', 'm', 'o', 'a', 'p', 'i', 'n', 'g'}]


def letter_sets(sentence):
    pass


if __name__ == "__main__":
    print(letter_sets("Je suis un as de la programmation"))
