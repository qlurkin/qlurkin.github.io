# Ecrire une fonction nommée LEN() qui prend une liste de
# listes en paramètre et qui renvoie la liste des longueurs des listes.

def LEN(L):
	# Votre code ici

print(LEN([[1], [2, 3], [4, 5, 42]])) # affiche [1, 2, 3]
