# Ecrire une fonction nommée words() qui reçoit une
# phrase (string) et qui renvoie la liste des mots.

def words(s):
	# Votre code ici

print(words("je suis étudiant")) # affiche ['je', 'suis', 'étudiant']
