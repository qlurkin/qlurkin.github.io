# Ecrire une fonction nommée sentence() qui prend une liste de mots (string)
# en paramètre et renvoie une chaîne de caractères contenant les mots dans
# l’ordre séparés par des espaces.

def sentence(L):
	# Votre code ici

print(sentence(["je", "suis", "étudiant"])) # affiche "je suis étudiant"
