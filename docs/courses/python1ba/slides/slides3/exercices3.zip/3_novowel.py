# Ecrire une fonction nommée noVowel() qui reçoit une chaîne
# de caractères et qui renvoie la même chaîne où toutes les
# voyelles ont été remplacées par des "*".

def noVowel(s):
	# Votre code ici

print(noVowel("je suis student")) # affiche "j* s**s st*d*nt"
