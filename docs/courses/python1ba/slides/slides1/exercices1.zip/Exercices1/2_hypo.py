# Ecrire une fonction nommée hypo() qui reçoit les longueurs des deux côtés de l’angle droit d’un triangle rectangle et qui renvoie la longueur de l’hypoténuse.

def hypo(a, b):
	# Votre code ici

print(hypo(3, 4)) # Devrait afficher 5.0