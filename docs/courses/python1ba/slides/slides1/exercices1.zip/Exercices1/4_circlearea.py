# Ecrire une fonction nommée circleArea() qui reçoit le rayon d’un cercle et qui en renvoie la surface.

def circleArea(r):
	# Votre code ici

print(circleArea(1))
