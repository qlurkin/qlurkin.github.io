# La somme des amplitudes des angles d’un triangle vaut toujours 180° en géométrie euclidienne. Ecrire une fonction nommée thirdAngle() qui reçoit les amplitudes de deux angles d’un triangle et qui renvoie l’amplitude du troisième.

def thirdAngle(a, b):
	# Votre code ici

print(thirdAngle(45, 90)) # Devrait afficher 45