# Ecrire une fonction nommée max() qui reçoit
# 3 nombres et renvoie le plus grand des trois.

def max(a, b, c):
	# Votre code ici

print(max(3, 42, -5))