# Ecrire une fonction nommée max() qui reçoit
# 3 nombres et renvoie le plus grand des trois.

def max(a, b, c):
	# Votre code ici

if __name__ == '__main__':
	print(max(3, 42, -5))
