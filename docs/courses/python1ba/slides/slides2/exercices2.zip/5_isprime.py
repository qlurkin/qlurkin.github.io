# Ecrire une fonction nommée isPrime() qui renvoie True
# si le nombre passé en paramètre est premier.
# Un nombre premier est un nombre entier positif qui a
# exactement 2 diviseurs (1 et lui-même).
# Exemple: 5 est premier car il n’est divisible que par 1 et 5.
# 1 n'est pas premier car il n'a qu'un diviseur.

def isPrime(n):
	# Votre code ici

if __name__ == '__main__':
	print(isPrime(1)) # False
	print(isPrime(5)) # True
