# Ecrire une fonction nommée abs() qui prend un nombre en
# paramètre et qui renvoie la valeur absolue de ce nombre.

def abs(x):
	# Votre code ici

if __name__ == '__main__':
	print(abs(5))
	print(abs(-3))
