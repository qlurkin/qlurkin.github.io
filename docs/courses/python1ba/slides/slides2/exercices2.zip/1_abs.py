# Ecrire une fonction nommée abs() qui prend un nombre en
# paramètre et qui renvoie la valeur absolue de ce nombre.

def abs(x):
	# Votre code ici

print(abs(5))
print(abs(-3))