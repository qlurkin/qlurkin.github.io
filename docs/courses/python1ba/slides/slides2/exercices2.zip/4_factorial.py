# Ecrire un fonction nommée factorial() qui reçoit un entier
# en paramètre et qui renvoie sa factorielle. La factorielle
# se calcule comme suit:
#      factorial(n) = 1*2*3*4*...*n
# il est interdit d'importer le module math

def factorial(n):
	# Votre code ici

print(factorial(5)) # devrait afficher 120