# Ecrire une fonction nommée words() qui reçoit une
# phrase (string) et qui renvoie la liste des mots.

def words(s):
	# Votre code ici

if __name__ == '__main__':
	print(words("je suis étudiant")) # affiche ['je', 'suis', 'étudiant']
