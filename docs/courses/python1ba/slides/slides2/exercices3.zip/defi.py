# A partir du défis du cours 2, animez n cercles en x et en y
# rebondissant sur les bords de la fenêtre
# (pour n étant un entier positif)


