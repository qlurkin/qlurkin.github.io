# Ecrire une fonction nommée findAll() qui reçoit une liste
# et une valeur à chercher dans la liste.
# Elle renverra la liste des indices auxquels l’élément
# recherché apparait

def findAll(L, elem):
	# Votre code ici

if __name__ == '__main__':
	print(findAll([1, 42, 2, 3, 42], 42)) # affiche [1, 4]
