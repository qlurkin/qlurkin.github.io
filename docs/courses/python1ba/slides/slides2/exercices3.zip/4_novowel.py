# Ecrire une fonction nommée noVowel() qui reçoit une chaîne
# de caractères et qui renvoie la même chaîne où toutes les
# voyelles ont été remplacées par des "*".

def noVowel(s):
	# Votre code ici

if __name__ == '__main__':
	print(noVowel("je suis student")) # affiche "j* s**s st*d*nt"
