# Ecrire une fonction nommée longest() qui prend une liste
# de chaînes de caractères en paramètre et qui renvoie la
# chaîne la plus longue de la liste.

def longest(L):
    # Votre code ici

if __name__ == "__main__":
    # affiche "quatre"
    print(longest(["un", "deux", "trois", "quatre", "cinq"]))
