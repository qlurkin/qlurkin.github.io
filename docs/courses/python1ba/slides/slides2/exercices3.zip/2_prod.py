# Ecrire une fonction nommée prod() qui prend une liste
# en paramètre et qui renvoie le produit des éléments de
# la liste

def prod(L):
    # Votre code ici

if __name__ == '__main__':
    # affiche 6
    print(prod([1, 2, 3]))
