# Ecrire une fonction nommée zipper() qui reçoit 2 listes en paramètres et qui renvoie
# une liste contenant les éléments des deux listes alternés. Attention, Les
# deux listes peuvent être de tailles différentes

def zipper(L1, L2):
    # Votre code ici

print(zipper([1, 3, 5], [6, 4, 2, 1])) # [1, 6, 3, 4, 5, 2, 1]