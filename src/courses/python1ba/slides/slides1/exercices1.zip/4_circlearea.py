# Ecrire une fonction nommée circleArea() qui reçoit le rayon d’un cercle
# et qui en renvoie la surface.

def circleArea(r):
	# Votre code ici

if __name__ == '__main__':
	print(circleArea(1))
