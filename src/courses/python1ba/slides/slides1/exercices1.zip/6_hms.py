# Ecrire une fonction nommée HMS() qui reçoit un nombre de seconde 
# en paramètre et qui renvoie une chaîne de caractères avec les 
# nombres d’heures, de minutes et de secondes correspondant (au format H:M:S).

def HMS(s):
	# Votre code ici

if __name__ == '__main__':
	print(HMS(12345)) # Devrait afficher 3:25:45
