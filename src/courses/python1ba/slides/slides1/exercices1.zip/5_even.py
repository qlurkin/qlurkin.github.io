# Ecrire une fonction nommée even() qui renvoie la valeur booléenne True
# si elle reçoit un nombre pair et False dans le cas contraire.

def even(n):
	# Votre code ici

if __name__ == '__main__':
	print(even(4))
	print(even(5))
