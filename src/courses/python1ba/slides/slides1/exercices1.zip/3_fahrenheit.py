# La relation entre températeure en degrés Celcius (Tc) et en degrés Fahrenheit (Tf) est la suivante:
#         Tf = 1.8 * Tc + 32
# Ecrivez deux fonctions. L’une, nommée fah2cel() transforme les degrés Fahrenheit en degrés Celcius.
# L’autre, nommée cel2fah() transforme les degrés Celcius en degrés Fahrenheit.

def fah2cel(Tf):
	# Votre code ici

def cel2fah(Tc):
	# Votre code ici

if __name__ == '__main__':
	print(fah2cel(0))
	print(cel2fah(0))
