# Ecrire une fonction nommée fibo() qui prend un entier n en paramètre et qui
# renvoie le n-ième terme de la suite de Fibonacci.
# La suite de Fibonacci est une suite où chaque terme est égal à la somme des
# deux termes précédents. Les deux premiers termes sont égaux à 1. Les termes
# sont numérotés à partir de 1.

def fibo(n):
	# Votre code ici

print(fibo(2))  # affiche 1
print(fibo(3))  # affiche 2
print(fibo(10)) # affiche 55
