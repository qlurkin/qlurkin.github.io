# Ecrire une fonction nommée unique() qui reçoit une liste en paramètre et qui
# renvoie une nouvelle liste contenant une fois chaque élément de la liste
# d’entrée, dans l'ordre d'apparition de la 1ère occurrence.

def unique(L):
	# Votre code ici

print(unique([1, 2, 3, 2, 42, 5, 42])) # affiche [1, 2, 3, 42, 5]